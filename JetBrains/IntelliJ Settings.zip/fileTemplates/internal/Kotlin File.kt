#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}

/**
 * 
 *
 * @author        Eric Gustafson
 * @date_created  ${DATE}
 * @version       1.0
 */
 
#end
#parse("File Header.java")
