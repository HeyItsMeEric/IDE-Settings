#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}

#end
#parse("File Header.java")

/**
 * 
 *
 * @author        Eric Gustafson
 * @date_created  ${DATE}
 * @version       1.0
 */
 
enum class ${NAME} {
}